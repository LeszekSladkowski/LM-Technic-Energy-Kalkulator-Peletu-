L&M Technic Energy — Europejski Kalkulator Peletu 1.2 PREMIUM
V31.3.3 — UPDATE ENGINE + MOBILE SETTINGS FIX

Naprawiono:
1. Usunięto stary moduł aktualizacji V31.0.11 z invoice-v31.js, który nadpisywał nowszy updater i pokazywał fałszywie V31.0.11.
2. Jedynym źródłem numeru wersji i mechanizmu aktualizacji jest app-main.js.
3. USTAWIENIA nie mają już stałej szerokości 941 px i działają pionowo na telefonie.
4. Karty RYNKI EU pozostają bez zmian względem V31.3.2 — ta poprawka nie przebudowuje zatwierdzonej grafiki.
