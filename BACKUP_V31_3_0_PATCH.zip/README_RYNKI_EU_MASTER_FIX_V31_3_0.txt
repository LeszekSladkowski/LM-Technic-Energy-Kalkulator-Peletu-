L&M TECHNIC ENERGY — EUROPEJSKI KALKULATOR PELETU 1.2 PREMIUM
WERSJA: V31.3.0 RYNKI EU MASTER FIX
DATA: 21.08.2026

NAPRAWIONE BŁĘDY:
1. PULPIT: automatyczne dopasowanie do szerokości ekranu telefonu bez ręcznego zwężania palcami.
2. KARTA NR 1 RYNKI EUROPY: ostateczny standard, 12 państw, falujące flagi ze złotym masztem, pełne dopasowanie.
3. KARTA NR 2 KRAJU: przywrócona jako osobny ekran między Kartą 1 i CRM; telefon zielony, mapa niebieska, menu/lista mocno pomarańczowa Orange.
4. KARTA NR 3 CRM: osobny ekran po wybraniu firmy z Karty 2; flaga kraju przy nazwie kraju; akcje zielony/niebieski/Orange.
5. RODO: jasny panel danych kontaktowych jest domyślnie zamknięty. Otwiera go wyłącznie mały biały przycisk ••• obok nazwy firmy. Pomarańczowy przycisk listy nie ujawnia danych kontaktowych.
6. Zachowana logika statusów CRM, przenoszenie zatwierdzonych klientów/dostawców i generator oferty.
7. Dodano pliki referencyjne MASTER_RYNKI_EU_KARTA_1/2/3_CRM.png w katalogu assets.

PRZEPŁYW:
PULPIT → RYNKI EUROPY (Karta 1) → WYBRANY KRAJ (Karta 2) → CRM / STATUS FIRMY (Karta 3).

UWAGA:
Po wgraniu na GitHub Pages stara instalacja PWA może wymagać jednego odświeżenia/aktualizacji Service Workera. Cache ma nowy numer V31.3.0-RYNKI-EU-MASTER-FIX.
