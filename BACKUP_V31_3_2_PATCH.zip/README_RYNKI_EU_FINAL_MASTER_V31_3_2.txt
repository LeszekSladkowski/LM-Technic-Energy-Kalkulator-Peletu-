L&M Technic Energy — V31.3.2 FINAL MASTER RYNKI EU
21.08.2026

Karta 1, Karta 2 i Karta 3 CRM są wdrożone jako natywne mobilne ekrany bez zoom 941 px.
W assets znajdują się trzy niezmienne zatwierdzone wzorce PNG.
Karta 2: telefon zielony, mapa niebieska, menu Orange; menu prowadzi do CRM.
Karta 3: biały przycisk i przy nazwie otwiera dane RODO; panel jest domyślnie ukryty. Pomarańczowe menu służy do statusu i generatora oferty.
