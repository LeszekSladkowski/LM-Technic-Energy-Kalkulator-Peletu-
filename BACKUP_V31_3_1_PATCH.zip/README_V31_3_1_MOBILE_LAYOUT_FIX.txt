L&M Technic Energy — Europejski Kalkulator Peletu 1.2 PREMIUM
V31.3.1 MOBILE LAYOUT FIX — 21.08.2026

Naprawa po rzeczywistych zrzutach z telefonu:
- Karta 1 RYNKI EUROPY: usunięte sztuczne pomniejszanie całej planszy do 941 px; interfejs wypełnia ekran telefonu bez dużej czarnej pustej przestrzeni.
- Karta 2 kraju: pozostawiona bez zmiany skalowania i bez zmiany zatwierdzonej grafiki/kolorów.
- Karta 3 CRM: usunięte sztuczne pomniejszanie do 941 px; działa natywny układ mobilny i pionowe przewijanie, zamiast miniatury całej karty.
- Zachowane: flaga kraju, biały przycisk prywatnych danych RODO, zielony telefon, niebieska mapa, pomarańczowy Orange szczegóły/oferta, wiadomości asystenta.
- Nowy cache Service Workera: V31.3.1-MOBILE-LAYOUT-FIX.
